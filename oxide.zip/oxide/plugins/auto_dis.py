"""
Copyright 2023 National Technology & Engineering Solutions
of Sandia, LLC (NTESS). Under the terms of Contract DE-NA0003525 with NTESS,
the U.S. Government retains certain rights in this software.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

"""Plugin: re_tools - Functions to help reverse engineer an x86 file
"""

import os, tempfile, struct

from core import api
from re_lib import instruction_to_string, get_slice
from core.oshell import OxideShell, ShellSyntaxError

myshell = OxideShell()
current_file = None
default_height = 20
default_width = 8
""" Available colors are 'red', 'blue', 'green', 'cyan', 'magenta'
    Available effects are 'bold' and 'underline'
"""



def disassembly(args, opts):
    """
        Displays the disassembly for a file
        Syntax: disassembly <oid> [--slice=<beg>:<end>]
    """
    print("here!!!1")
    args, invalid = api.valid_oids(args)
    args = api.expand_oids(args)
    if not args:
        if current_file:
            args = [current_file]
        else:
            raise ShellSyntaxError("Must provide an oid")

    for oid in args:
        # disasm = api.get_field("disassembly", [oid], "instructions", mod_opts)
        disasm = api.retrieve('disassembly', oid, {'disassembler': 'ghidra_disasm'})

        disasm = disasm.pop(list(disasm.keys())[0])

        for addrs, istr in disasm['instructions'].items():
            print(addrs)
            print(istr)
            break
        #comments = api.get_field("disassembly", [oid], "comments", mod_opts)

exports = [disassembly]
