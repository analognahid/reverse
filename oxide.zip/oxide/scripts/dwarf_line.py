from ghidra.app.script import GhidraScript

setAnalysisOption(currentProgram, "DWARF Line Number", "true")
setAnalysisOption(currentProgram, "DWARF", "true")

print(getCurrentAnalysisOptionsAndValues(currentProgram))

print("xing" + 40*"!!!!!!!!!!!")