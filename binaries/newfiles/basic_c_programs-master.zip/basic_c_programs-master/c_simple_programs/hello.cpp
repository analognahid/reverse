#include <iostream>

using namespace std;
int main()
{
	wchar_t name;
	cout << "hello waht is your name : ";
	cin.get >> name;
	cout << name;

	return 0;
}
