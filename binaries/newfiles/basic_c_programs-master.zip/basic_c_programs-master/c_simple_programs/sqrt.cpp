// =============================================================================
// -------------------------x Square root of  integers x------------------------
// =============================================================================
// demonstrate sqrt() library function
// Author : Suraj Singh Bisht
// Email : surajsinghbisht054@gmail.com
// Code : C++

#include <iostream>
#include <math.h>
using namespace std; 

int main(){
	double number, answer;
	cout << "\n [+] Enter Number For Finding Square Root : " ;
	cin >> number;
	answer=sqrt(number);
	cout << "\n [+] Your Square root is : "<< answer <<endl;
} 
