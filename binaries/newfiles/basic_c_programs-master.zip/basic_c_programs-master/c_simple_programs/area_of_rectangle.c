// Author : Suraj Singh Bisht
// Email : surajsinghbisht054@gmail.com
// Code : C
// 
//  To FInd Area Of Rectagle


#include<stdio.h>

int main(){
	int l, b, area;
	printf("\n%s", "[+] Enter Length & Width Of Rectangle : ");
	scanf("%d %d",&l,&b);
	area = l * b;
	printf("\n[+] Area Of Rectangle : %d \n", area);
	
}
