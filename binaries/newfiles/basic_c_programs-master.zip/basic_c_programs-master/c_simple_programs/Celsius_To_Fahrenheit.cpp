// ===============================================================================
// ===============x Celesius To Fahrenheit Converter x----------------------------
// ===============================================================================
// demonstrate cin, newline


#include <iostream>
#include <stdio.h>
using namespace std;


int main () {
	string a;
	int ftemp, degree;
	cout << "\n [+] Please Enter Celsius Temperature :   ";
	cin >> degree;
	//degree=(ftemp-32)*5/9;
	ftemp=(degree*9/5)+32;
	cout << "\n [+] Your Temperature in Fahrenheit : " << ftemp << endl;
	cin >> ;
	
	// formula fahrenheit=(ftemp-32)*5/9 
	}
