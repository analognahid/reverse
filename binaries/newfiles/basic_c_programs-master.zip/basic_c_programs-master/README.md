# Beginners Basic C programs
Collection Of Some Basic Programs In C/C++ 

## Like 

- WeekDay_Finder.cpp (Find Weekday from the corresponding weekday )


### Author
* Suraj Singh Bisht
- surajsinghbisht054@gmail.com
