
int add(int a, int b);

float addf(float a, float b);


int substract(int a, int b);

float substractf(float a, float b);
