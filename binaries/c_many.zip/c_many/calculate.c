#include "calculate.h"
#include <stdio.h>
#include <stdlib.h>

int add(int a, int b){
    int ran = 10;
    ran = ran +12;
    ran =ran*ran;
    float fran =0.12;
    fran = fran+1.0;
    for (int i = 0; i<10;i++){
        int fran = 0;
        fran=fran+2;
    }
    ran =ran -10;
    return a+b+ran;
}
float addf(float a, float b){
    return a+b;
}


int substract(int a, int b){
    return a-b;
}
float substractf(float a, float b){
    return a-b;
}


